from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Product, CartItem, Order, OrderItem
from .forms import ProductForm, OrderForm

class ProductListView(ListView):
    model = Product
    template_name = 'product_list.html'
    paginate_by = 10

    def get_queryset(self):
        query = self.request.GET.get('q')
        if query:
            return Product.objects.filter(name__icontains=query, stock__gt=0).order_by('category', 'name')
        return Product.objects.filter(stock__gt=0).order_by('category', 'name')

class ProductDetailView(DetailView):
    model = Product
    template_name = 'product_detail.html'

class ProductCreateView(CreateView):
    model = Product
    form_class = ProductForm
    template_name = 'product_form.html'
    success_url = '/'

class ProductUpdateView(UpdateView):
    model = Product
    form_class = ProductForm
    template_name = 'product_form.html'
    success_url = '/'

class ProductDeleteView(DeleteView):
    model = Product
    template_name = 'product_confirm_delete.html'
    success_url = '/'

def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    cart_item, created = CartItem.objects.get_or_create(product=product)
    if not created:
        if cart_item.quantity < product.stock:
            cart_item.quantity += 1
    else:
        if product.stock > 0:
            cart_item.quantity = 1
    cart_item.save()
    return HttpResponseRedirect(reverse('product_list'))

def remove_from_cart(request, pk):
    cart_item = get_object_or_404(CartItem, pk=pk)
    cart_item.delete()
    return HttpResponseRedirect(reverse('cart_view'))

class CartView(ListView):
    model = CartItem
    template_name = 'cart_view.html'

def checkout(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save()
            cart_items = CartItem.objects.all()
            for item in cart_items:
                OrderItem.objects.create(
                    order=order,
                    product=item.product,
                    quantity=item.quantity
                )
            cart_items.delete()
            return redirect('product_list')
    else:
        form = OrderForm()
    return render(request, 'checkout.html', {'form': form})
